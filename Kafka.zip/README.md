# Trabalho Final - SSC0904 - Sistemas Computacionais Distribuídos - ProjetoSUS

O projeto tem como objetivo o desenvolvimento de uma aplicação dsitribuída para o gerenciamento de estoques de medicamentos disponíveis gratuitamente pelo SUS / ANVISA.

O grupo decidiu por usar o banco de dados MongoDB, com Javascript para realizar a modelagem dos modelos. Foi utilizado, também, Python para realizar o gerenciamento do Apache Kafka.

## Diagrama


## Instalação

## Uso
